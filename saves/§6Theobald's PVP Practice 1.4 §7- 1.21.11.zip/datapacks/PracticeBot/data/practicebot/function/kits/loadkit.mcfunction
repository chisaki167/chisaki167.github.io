execute as @a[name=!TheobaldTheBot] if score @s kit matches 1 run function practicebot:kits/kit1 
execute as @a[name=!TheobaldTheBot] if score @s kit matches 2 run function practicebot:kits/kit2 
execute as @a[name=!TheobaldTheBot] if score @s kit matches 3 run function practicebot:kits/kit3 
execute as @a[name=!TheobaldTheBot] if score @s kit matches 4 run function practicebot:kits/kit4 
kill @e[type=minecraft:splash_potion,nbt={Item:{id:"minecraft:splash_potion",count:1,components:{"minecraft:max_stack_size":69,"minecraft:potion_contents":{potion:"minecraft:luck"}}}}]
stopsound @a[name=!TheobaldTheBot] * minecraft:entity.splash_potion.throw