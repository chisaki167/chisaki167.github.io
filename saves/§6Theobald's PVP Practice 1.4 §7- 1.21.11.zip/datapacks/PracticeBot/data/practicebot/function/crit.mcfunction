player TheobaldTheBot stop
player TheobaldTheBot move forward
player TheobaldTheBot unsprint
player TheobaldTheBot attack once

scoreboard players set TheobaldTheBot hitcd 11
execute as TheobaldTheBot if entity @s[tag=shield,tag=sword] run schedule function practicebot:usecontinuous 2t