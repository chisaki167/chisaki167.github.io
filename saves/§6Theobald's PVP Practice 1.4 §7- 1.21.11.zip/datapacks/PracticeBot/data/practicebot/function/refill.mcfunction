tag @a remove norefill
# tag @a[name=!TheobaldTheBot,nbt={SelectedItem:{id:"minecraft:totem_of_undying"}}] add norefill
# tag @a[name=!TheobaldTheBot,nbt={SelectedItem:{id:"minecraft:tnt_minecart"}}] add norefill
tag @a[name=!TheobaldTheBot,nbt={SelectedItem:{id:"minecraft:bucket"}}] add norefill
# tag @a[name=!TheobaldTheBot,nbt={SelectedItem:{id:"minecraft:splash_potion"}}] add norefill
execute if entity @p[name=TheobaldTheBot,gamemode=creative] run tag @a[name=!TheobaldTheBot] add norefill

item modify entity @a[tag=!norefill,gamemode=!creative,name=!TheobaldTheBot] weapon.mainhand practicebot:refill
item modify entity @a[tag=!norefill,gamemode=!creative,name=!TheobaldTheBot] weapon.offhand practicebot:refill
item modify entity @a[tag=!norefill,name=TheobaldTheBot] weapon.mainhand practicebot:refill