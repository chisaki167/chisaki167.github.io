execute if block 8 20 8 lever[powered=false] run tp @a[name=!TheobaldTheBot] -66.5 141 -543.5 180 0
execute if block 8 20 8 lever[powered=false] run tp TheobaldTheBot -66.5 141 -553.5 0 0

execute if block 8 20 8 lever[powered=true] run tp @a[name=!TheobaldTheBot] -266.5 141 -743.5 180 0
execute if block 8 20 8 lever[powered=true] run tp TheobaldTheBot -266.5 141 -753.5 0 0

scoreboard players set TheobaldTheBot holeused 1