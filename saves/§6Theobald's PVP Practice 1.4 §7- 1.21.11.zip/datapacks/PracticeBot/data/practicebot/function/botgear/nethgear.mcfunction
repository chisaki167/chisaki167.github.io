clear @s
execute as TheobaldTheBot run function practicebot:refilltotem

item replace entity @s armor.head with minecraft:netherite_helmet[minecraft:enchantments={"minecraft:protection":4},minecraft:unbreakable={}]
item replace entity @s armor.chest with minecraft:netherite_chestplate[minecraft:enchantments={"minecraft:protection":4},minecraft:unbreakable={}]
item replace entity @s armor.legs with minecraft:netherite_leggings[minecraft:enchantments={"minecraft:blast_protection":4},minecraft:unbreakable={}]
item replace entity @s armor.feet with minecraft:netherite_boots[minecraft:enchantments={"minecraft:feather_falling":4,"minecraft:protection":4},minecraft:unbreakable={}]

execute as TheobaldTheBot if entity @s[tag=plegs] run item replace entity @s armor.legs with minecraft:netherite_leggings[minecraft:enchantments={"minecraft:swift_sneak":3,"minecraft:protection":4},minecraft:unbreakable={}]
execute as TheobaldTheBot if entity @s[tag=doublebp] run item replace entity @s armor.feet with minecraft:netherite_boots[minecraft:enchantments={"minecraft:feather_falling":4,"minecraft:blast_protection":4},minecraft:unbreakable={}]

item replace entity @s hotbar.0 with minecraft:netherite_sword[enchantments={"minecraft:sharpness":5,"minecraft:knockback":1},minecraft:unbreakable={}]
item replace entity @s hotbar.1 with minecraft:obsidian 64
item replace entity @s hotbar.2 with minecraft:end_crystal 64
item replace entity @s hotbar.3 with minecraft:netherite_axe
item replace entity @s hotbar.4 with minecraft:golden_apple 64
item replace entity @s hotbar.5 with minecraft:respawn_anchor 64
item replace entity @s hotbar.6 with minecraft:glowstone 64
item replace entity @s inventory.0 with minecraft:tipped_arrow 64
item replace entity @s hotbar.7 with minecraft:ender_pearl 16
item replace entity @s hotbar.8 with totem_of_undying

execute as TheobaldTheBot if entity @s[tag=sword,tag=!shield] run item replace entity @s hotbar.0 with minecraft:netherite_sword[minecraft:enchantments={"minecraft:sharpness":5},minecraft:unbreakable={}]
execute as TheobaldTheBot if entity @s[tag=sword,tag=shield] run item replace entity @s hotbar.0 with minecraft:netherite_sword[minecraft:enchantments={"minecraft:sharpness":5,"minecraft:knockback":1,"minecraft:fire_aspect":2},minecraft:unbreakable={}]