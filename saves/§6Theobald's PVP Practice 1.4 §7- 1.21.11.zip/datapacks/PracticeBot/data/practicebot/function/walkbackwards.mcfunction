execute at TheobaldTheBot if entity @p[name=!TheobaldTheBot,distanceH=..5] run player TheobaldTheBot move backward
execute at TheobaldTheBot as @p[name=!TheobaldTheBot] if items entity @s[distanceH=5..6.9] weapon.mainhand minecraft:respawn_anchor run player TheobaldTheBot move backward
execute at TheobaldTheBot as @p[name=!TheobaldTheBot] unless items entity @s[distanceH=5..7] weapon.mainhand minecraft:respawn_anchor run player TheobaldTheBot move
execute at TheobaldTheBot if entity @p[name=!TheobaldTheBot,distanceH=7..7.5] run player TheobaldTheBot move
execute at TheobaldTheBot if entity @p[name=!TheobaldTheBot,distanceH=7.5..] run player TheobaldTheBot move forward