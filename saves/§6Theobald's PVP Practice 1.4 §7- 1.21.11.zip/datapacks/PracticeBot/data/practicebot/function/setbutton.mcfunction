execute unless block 8 60 8 minecraft:polished_blackstone_button[face=floor] run setblock 8 61 8 minecraft:polished_blackstone_button[face=floor]
execute as TheobaldTheBot if entity @s[tag=crystal] unless block 8 61 8 stripped_cherry_log run setblock 8 60 8 stripped_cherry_log
execute as TheobaldTheBot if entity @s[tag=!crystal] unless block 8 61 8 minecraft:stripped_bamboo_block run setblock 8 60 8 minecraft:stripped_bamboo_block

execute as TheobaldTheBot if entity @s[tag=crystal] run setblock 7 60 8 minecraft:ochre_froglight
execute as TheobaldTheBot if entity @s[tag=crystal] run setblock 8 60 9 minecraft:ochre_froglight
execute as TheobaldTheBot if entity @s[tag=crystal] run setblock 9 60 8 minecraft:ochre_froglight
execute as TheobaldTheBot if entity @s[tag=crystal] run setblock 8 60 7 minecraft:ochre_froglight

execute as TheobaldTheBot if entity @s[tag=!crystal] run setblock 7 60 8 minecraft:verdant_froglight
execute as TheobaldTheBot if entity @s[tag=!crystal] run setblock 8 60 9 minecraft:verdant_froglight
execute as TheobaldTheBot if entity @s[tag=!crystal] run setblock 9 60 8 minecraft:verdant_froglight
execute as TheobaldTheBot if entity @s[tag=!crystal] run setblock 8 60 7 minecraft:verdant_froglight

execute unless block 8 61 3 minecraft:polished_blackstone_button as TheobaldTheBot if entity @s[tag=crystal] if score @s difficulty matches 0..1 run clone 8 21 4 8 20 5 8 61 2
execute unless block 8 61 2 minecraft:command_block as TheobaldTheBot if entity @s[tag=crystal] if score @s difficulty matches 0..1 run clone 8 21 4 8 20 5 8 61 2
execute unless block 8 62 2 minecraft:oak_sign as TheobaldTheBot if entity @s[tag=crystal] if score @s difficulty matches 0..1 run clone 8 21 4 8 20 5 8 61 2