effect give @a[tag=!crystal] fire_resistance 1 0 true
effect give @a[tag=!crystal] resistance 1 4 true
effect give @a[tag=!crystal] saturation 1 99 true