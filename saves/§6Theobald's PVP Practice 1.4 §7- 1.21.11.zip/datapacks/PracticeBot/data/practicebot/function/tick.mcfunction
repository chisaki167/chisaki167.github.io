execute if entity @a[name=TheobaldTheBot,tag=speed] run effect give @a speed 2 1 true
execute at @a[name=TheobaldTheBot,gamemode=creative] run function practicebot:look
execute as TheobaldTheBot if entity @s[gamemode=!creative,tag=sword] run function practicebot:sword
execute as TheobaldTheBot if entity @s[gamemode=!creative,tag=crystal] run function practicebot:crystal
execute as @e[type=#arrows,nbt={inGround:1b}] run kill @s
function practicebot:setbutton
#execute if entity @p[name=TheobaldTheBot,gamemode=creative] run effect give @a resistance 2 255 true
#execute if entity @p[name=TheobaldTheBot,gamemode=creative] run effect give @a saturation 2 255 true

execute as @a[scores={death=1..},name=!TheobaldTheBot] run function practicebot:reset
execute as TheobaldTheBot if entity @s[tag=sword] if entity @a[name=!TheobaldTheBot,nbt=!{Inventory:[{id:"minecraft:barrier",Slot:17b}]},scores={kitloaded=0}] run function practicebot:reset

execute as @e[type=snowball] at @s run item modify entity @p weapon.mainhand practicebot:refill
execute as @e[type=minecraft:snowball] at @s if entity @p[name=!TheobaldTheBot,distance=..10] run ride TheobaldTheBot mount @s
execute as @e[type=minecraft:snowball] at @s if entity @p[name=!TheobaldTheBot,distance=10..] run ride TheobaldTheBot dismount
execute as @e[type=minecraft:snowball] at @s if entity @p[name=!TheobaldTheBot,distance=10..] run kill @s
execute as @e[type=minecraft:wind_charge] at @s unless entity @p[distance=..40] run kill @s

execute as @e[type=egg] at @s run function practicebot:egg

execute as @e[type=minecraft:splash_potion,nbt={Item:{id:"minecraft:splash_potion",count:1,components:{"minecraft:max_stack_size":69,"minecraft:potion_contents":{potion:"minecraft:luck"}}}}] as @a[name=!TheobaldTheBot] run function practicebot:kits/loadkit

execute as @e[type=interaction] run data remove entity @s attack
execute as @e[type=interaction] run data remove entity @s interaction

execute as @p[name=!TheobaldTheBot] store result score @s dtick run data get entity @s HurtTime 1

execute as @a if items entity @s weapon.mainhand minecraft:magma_cream run effect give @s minecraft:fire_resistance 1 4 true
execute as @a if items entity @s weapon.offhand minecraft:magma_cream run effect give @s minecraft:fire_resistance 1 4 true

execute if items entity TheobaldTheBot weapon.mainhand ender_pearl run item replace entity TheobaldTheBot weapon.mainhand with ender_pearl[max_stack_size=99] 99
execute at @e[type=tnt,tag=ignited,nbt={fuse:20s}] run playsound minecraft:block.grass.place block @a ~ ~ ~ 1 .8
#execute at @e[type=tnt,tag=ignited,nbt={fuse:20s}] run playsound minecraft:entity.tnt.primed block @a ~ ~ ~ 1 .8