tag TheobaldTheBot add pearlspam
execute as TheobaldTheBot at @s at @p[name=!TheobaldTheBot,distanceH=5..] run function practicebot:look
execute as TheobaldTheBot at @s at @p[name=!TheobaldTheBot,distanceH=..5] run player TheobaldTheBot look down
player TheobaldTheBot hotbar 8
player TheobaldTheBot use once
schedule function practicebot:pearlspamuntagger 2t