execute at TheobaldTheBot if entity @p[name=!TheobaldTheBot,distanceH=3.2..] run player TheobaldTheBot sprint
execute at TheobaldTheBot if entity @p[name=!TheobaldTheBot,distanceH=3.2..] run player TheobaldTheBot move forward
execute at TheobaldTheBot if entity @p[name=!TheobaldTheBot,distanceH=8..] unless entity @n[type=minecraft:ender_pearl] if items entity TheobaldTheBot weapon.mainhand minecraft:shield run player TheobaldTheBot use

execute at TheobaldTheBot if entity @p[name=!TheobaldTheBot,distanceH=1.2..3.2] run player TheobaldTheBot move
execute at TheobaldTheBot if entity @p[name=!TheobaldTheBot,distanceH=..1.2] run player TheobaldTheBot unsprint
execute at TheobaldTheBot if entity @p[name=!TheobaldTheBot,distanceH=..1.2] run player TheobaldTheBot move backward