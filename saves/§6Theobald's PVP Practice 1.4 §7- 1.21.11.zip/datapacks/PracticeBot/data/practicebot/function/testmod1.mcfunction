#function practicebot:testmod
title @a times 0 30 0
execute unless score @p[name=!TheobaldTheBot] modloaded matches 143.. run title HerobaneNair times 0 20 0
execute unless score @p[name=!TheobaldTheBot] modloaded matches 143.. run title @a subtitle {color:green,text:"https://modrinth.com/mod/herobot"}
execute unless score @p[name=!TheobaldTheBot] modloaded matches 143.. run tellraw @p {"click_event":{"action":"open_url","url":"https://modrinth.com/mod/herobot"},"color":"green","hover_event":{"action":"show_text","value":[{"text":"https://modrinth.com/mod/herobot"}]},"text":"https://modrinth.com/mod/herobot","underlined":true}
execute if score @p[name=!TheobaldTheBot] modloaded matches 0 run title @a title {color:red,text:"Download HeroBot from Modrinth"}
execute if score @p[name=!TheobaldTheBot] modloaded matches 1..142 run title @a title {color:red,text:"Update HeroBot"}