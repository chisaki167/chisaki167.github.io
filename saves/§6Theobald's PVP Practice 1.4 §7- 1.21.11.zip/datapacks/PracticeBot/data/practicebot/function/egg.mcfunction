kill @e[type=egg]
gamemode adventure @a[name=!TheobaldTheBot]
gamemode creative TheobaldTheBot
schedule function practicebot:reset 1t
tp @a[name=!TheobaldTheBot] 8.5 13 8.5 0 0
execute as @a[name=TheobaldTheBot,tag=crystal,scores={difficulty=1..}] run tellraw @a {"text": "<TheobaldTheBot> wise dodge kid"}