execute if score @s layer matches 205.. at @s run fill ~ ~ ~ ~199 ~ ~199 minecraft:air
execute if score @s layer matches 121..204 at @s run fill ~ ~ ~ ~199 ~ ~199 minecraft:netherrack
execute if score @s layer matches 61..120 at @s run fill ~ ~ ~ ~199 ~ ~199 minecraft:blackstone
execute if score @s layer matches 1..60 at @s run fill ~ ~ ~ ~199 ~ ~199 minecraft:basalt
execute if score @s layer matches 1 at @s run fill ~ ~-1 ~ ~599 ~ ~599 minecraft:bedrock