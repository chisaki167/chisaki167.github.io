execute if score @s layer matches 205.. at @s run fill ~ ~ ~ ~199 ~ ~199 minecraft:air
execute if score @s layer matches 204 at @s run fill ~ ~ ~ ~199 ~ ~199 minecraft:grass_block
execute if score @s layer matches 201..203 at @s run fill ~ ~ ~ ~199 ~ ~199 minecraft:dirt
execute if score @s layer matches 101..200 at @s run fill ~ ~ ~ ~199 ~ ~199 minecraft:stone
execute if score @s layer matches 1..100 at @s run fill ~ ~ ~ ~199 ~ ~199 minecraft:deepslate