execute if score TheobaldTheBot holemat matches 1 as @n[name=filler] run function practicebot:hole/bighole/plains
execute if score TheobaldTheBot holemat matches 2 as @n[name=filler] run function practicebot:hole/bighole/badlands
execute if score TheobaldTheBot holemat matches 3 as @n[name=filler] run function practicebot:hole/bighole/desert
execute if score TheobaldTheBot holemat matches 4 as @n[name=filler] run function practicebot:hole/bighole/snowy
execute if score TheobaldTheBot holemat matches 5 as @n[name=filler] run function practicebot:hole/bighole/nether
execute if score TheobaldTheBot holemat matches 6 as @n[name=filler] run function practicebot:hole/bighole/end

execute at @s run tp @s ~ ~-1 ~
scoreboard players remove @s layer 1
execute if score @s layer matches 0 at @s run fill ~-399 ~ ~-399 ~199 ~ ~199 minecraft:bedrock
execute if score @s layer matches 0 run title @a actionbar {"text":"Done Rebuilding BIG Hole","color":"green"}
execute if score @s layer matches 0 run kill @s
execute if score @s layer matches 1.. run function practicebot:hole/bighole/fill