execute if score @s layer matches 205.. at @s run fill ~ ~ ~ ~199 ~ ~199 minecraft:air
execute if score @s layer matches 204 at @s run fill ~ ~ ~ ~199 ~ ~199 minecraft:red_sand
execute if score @s layer matches 194..203 at @s run fill ~ ~ ~ ~199 ~ ~199 minecraft:terracotta
execute if score @s layer matches 101..193 at @s run fill ~ ~ ~ ~199 ~ ~199 minecraft:stone
execute if score @s layer matches 1..100 at @s run fill ~ ~ ~ ~199 ~ ~199 minecraft:deepslate