execute if score @s layer matches 205.. at @s run fill ~ ~ ~ ~199 ~ ~199 minecraft:air
execute if score @s layer matches 1..204 at @s run fill ~ ~ ~ ~199 ~ ~199 minecraft:end_stone