execute if score @s layer matches 205.. at @s run fill ~ ~ ~ ~199 ~ ~199 minecraft:air
execute if score @s layer matches 202..204 at @s run fill ~ ~ ~ ~199 ~ ~199 minecraft:sand
execute if score @s layer matches 197..201 at @s run fill ~ ~ ~ ~199 ~ ~199 minecraft:sandstone
execute if score @s layer matches 101..196 at @s run fill ~ ~ ~ ~199 ~ ~199 minecraft:stone
execute if score @s layer matches 1..100 at @s run fill ~ ~ ~ ~199 ~ ~199 minecraft:deepslate